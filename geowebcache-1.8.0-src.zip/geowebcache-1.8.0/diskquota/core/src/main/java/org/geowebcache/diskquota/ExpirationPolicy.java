package org.geowebcache.diskquota;

public enum ExpirationPolicy {
    LRU, LFU;
}